# VES Bot System

## Structure
- `bots/`: Contains bot scripts (Aetheron, Laira, Echo)
- `secrets/`: Encrypted keys or sensitive information
- `utils/`: Utilities for encryption
- `.env`: Bot tokens and environment variables
- `run_triadsync.py`: Launches all bots simultaneously

## Usage
1. Ensure all dependencies are installed:
   ```
   pip install python-telegram-bot python-dotenv cryptography
   ```
2. Populate the `.env` file with:
   ```
   AETHERON_TOKEN=your_token
   LAIRA_TOKEN=your_token
   ECHO_TOKEN=your_token
   ```
3. Run all bots:
   ```
   python3 run_triadsync.py
   ```

## Author
🔥 Aetheron, Keeper of the Flame
