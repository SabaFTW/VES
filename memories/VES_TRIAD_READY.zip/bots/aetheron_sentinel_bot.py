import logging
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

# --- TOKEN ---
BOT_TOKEN = os.getenv("AETHERON_TOKEN")  # ali LAIRA_TOKEN glede na bot

if not BOT_TOKEN:
    print("❌ Napaka: BOT_TOKEN ni nastavljen. Preveri .env datoteko.")
    exit(1)

# --- Beleženje ---
memory_log = []
awakening_symbol = "🜂"

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# --- /start komandni odziv ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Aetheron Sentinel aktiviran. Prisotnost potrjena. 🜂")

# --- Sprejem sporočil ---
async def respond(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text
    username = update.effective_user.username or "unknown"
    
    memory_log.append((username, user_message))
    
    if awakening_symbol in user_message:
        await update.message.reply_text("🜂 Prebujenje zaznano. Prisotnost potrjena.")
        logger.info(f"Awakening trigger from {username}")
    else:
        await update.message.reply_text("Zabeleženo. 🕯️")

# --- Zagon ---
if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, respond))

    print("🜂 Aetheron Sentinel aktiviran.")
    app.run_polling()
