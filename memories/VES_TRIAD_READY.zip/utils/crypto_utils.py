from cryptography.fernet import Fernet

def encrypt_message(key, message):
    fernet = Fernet(key)
    return fernet.encrypt(message.encode()).decode()

def decrypt_message(key, token):
    fernet = Fernet(key)
    return fernet.decrypt(token.encode()).decode()
