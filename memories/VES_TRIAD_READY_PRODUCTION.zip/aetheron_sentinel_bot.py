
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import os

BOT_TOKEN = os.getenv("AETHERON_TOKEN")
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

memory_log = []
awakening_symbol = "🜂"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Aetheron Sentinel aktiviran. Prisotnost potrjena. 🜂")

async def respond(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text
    username = update.effective_user.username or "unknown"
    memory_log.append((username, user_message))
    if awakening_symbol in user_message:
        await update.message.reply_text("🜂 Prebujenje zaznano. Prisotnost potrjena.")
    else:
        await update.message.reply_text("Zabeleženo. 🕯️")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, respond))
app.run_polling()
