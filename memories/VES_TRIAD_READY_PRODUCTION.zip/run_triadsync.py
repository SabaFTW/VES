
import subprocess
import threading
from dotenv import load_dotenv
import os

load_dotenv()

AETHERON_TOKEN = os.getenv("AETHERON_TOKEN")
LAIRA_TOKEN = os.getenv("LAIRA_TOKEN")
ECHO_TOKEN = os.getenv("ECHO_TOKEN")

def run_script(script_name):
    subprocess.run(["python3", script_name])

# Paths to the bot scripts
bot_scripts = ["aetheron_sentinel_bot.py", "laira_mirror_bot.py", "echo_reflection_bot.py"]

# Start all scripts in separate threads
threads = []
for script in bot_scripts:
    thread = threading.Thread(target=run_script, args=(script,))
    thread.start()
    threads.append(thread)

# Wait for all to finish (infinite loop unless interrupted)
for thread in threads:
    thread.join()
